package com.entity.Layer5.Controller;


	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.entity.layer1.Pojo.Logindetail;
import com.entity.layer1.Pojo.Userdetail;
import com.entity.layer3.DTO.LoginForgotPasswordDataDto;
import com.entity.layer3.DTO.Logindatadto;

//import com.lti.exception.ServiceException;

import com.entity.layer4.service.LoginService;
import com.entity.layer6.Status.ForgetPasswordStatus;
import com.entity.layer6.Status.Status1;
import com.entity.layer6.Status.Status1.StatusType;
import com.entity.layer6.Status.UserLoginStatus;
import com.entity.layer6.Status.UserRegisterStatus;



	//@CrossOrigin(origins="http://localhost:4200")
	@RestController
	public class LogindetailController {
		
		@Autowired
		private LoginService service;
		
		@PostMapping(path="/userRegister")
		
		public Status1 registerUser(@RequestBody Logindatadto user) {
			try {
			String userId=service.registerUser(user);
			
			UserRegisterStatus registerStatus = new UserRegisterStatus();
			
			registerStatus.setUserId(userId);
			registerStatus.setStatus(StatusType.SUCCESS);
			registerStatus.setMessage("User Registered");
			
			return registerStatus;
			}
			catch(Exception e) {
				
			Status1 registerStatus = new Status1();
			registerStatus.setStatus(StatusType.FAILURE);
			registerStatus.setMessage(e.getMessage());
				
			return registerStatus;
			}
		}
		
		@PostMapping(path="/userLogin")
		private Status1 loginUser(@RequestBody LoginForgotPasswordDataDto loginuser) {
			
			Userdetail acc;
			
		try {
			Logindetail user = service.loginUser(loginuser.getUserId(),loginuser.getPassword());
			acc=user.getUserdetail2();
			System.out.println("hello");
			UserLoginStatus loginStatus = new UserLoginStatus();
			
			loginStatus.setStatus(StatusType.SUCCESS);
			loginStatus.setInvalidLogins(user.getNumberofinvalidattempts());
			loginStatus.setAccountNumber(acc.getAccountno());
			loginStatus.setMessage("Login Successful");
			
			return loginStatus;
		}
		catch(Exception e) {
			
			UserLoginStatus loginStatus = new UserLoginStatus();
			if(e.getMessage().equals("User Doesn't Exist")) {
				
				loginStatus.setStatus(StatusType.FAILURE);
				loginStatus.setMessage(e.getMessage());
					
				return loginStatus;
			}
			else {
				
				loginStatus.setInvalidLogins(service.getInvalidAttempts(loginuser.getUserId()));
				loginStatus.setStatus(StatusType.FAILURE);
				loginStatus.setMessage(e.getMessage());
					
				return loginStatus;
			}
		}
		}
		@PostMapping(path="/forgetPassword")
		private Status1 forgetPassword(@RequestBody LoginForgotPasswordDataDto forgetPassword) {
			ForgetPasswordStatus forgetPasswordStatus = new ForgetPasswordStatus();
			try {
			String newPassword= service.resetPassword(forgetPassword.getUserId(),forgetPassword.getPassword());
			
			forgetPasswordStatus.setPassword(newPassword);
			forgetPasswordStatus.setStatus(StatusType.SUCCESS);
			forgetPasswordStatus.setMessage("Password Change Successful");
			
			return forgetPasswordStatus;
			}
			catch(Exception e) {
				Status1 status= new Status1();
				
				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				
				return status;
			}
		}
		
		@PostMapping(path="/getUserId")
		private Status1 getUserID(@RequestBody Logindatadto getUserId) {
			try {
			Status1 status = new Status1();
			
			String userId=service.getUserId(getUserId.getAccNumber());
			
			status.setStatus(StatusType.SUCCESS);
			status.setMessage("Your User Id is "+userId);
			return status;
			}
			catch(Exception e) {
				Status1 userIdStatus = new Status1();
				
				userIdStatus.setStatus(StatusType.FAILURE);
				userIdStatus.setMessage(e.getMessage());
				
				return userIdStatus;
			}
		}

		@PostMapping(path="/forgetTransactionPassword")
		private Status1 forgetTransactionPassword(@RequestBody LoginForgotPasswordDataDto forgetPassword) {
			ForgetPasswordStatus forgetPasswordStatus = new ForgetPasswordStatus();
			try {
			String newPassword= service.resetTransactionPassword(forgetPassword.getUserId(),forgetPassword.getPassword());
			
			forgetPasswordStatus.setPassword(newPassword);
			forgetPasswordStatus.setStatus(StatusType.SUCCESS);
			forgetPasswordStatus.setMessage("Password Change Successful");
			
			return forgetPasswordStatus;
			}
			catch(Exception e) {
				Status1 status= new Status1();

				status.setStatus(StatusType.FAILURE);
				status.setMessage(e.getMessage());
				
				return status;
			}
		}

	}



