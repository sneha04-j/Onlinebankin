package com.entity.layer4.service;

import java.util.List;

import com.entity.layer3.DTO.PayeedetailDTO;
import com.entity.layer3.DTO.viewPayeedetail;



public interface PayeedetailService {
	List<viewPayeedetail> getPayeeNameAndAccNo(String fromAcc);
	public void addPayeedetail(PayeedetailDTO payee) throws Exception;

	

}
