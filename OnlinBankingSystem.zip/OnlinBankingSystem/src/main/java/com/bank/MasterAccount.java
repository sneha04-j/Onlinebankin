package com.bank;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import org.springframework.boot.autoconfigure.cache.CacheType;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import com.entity.PayeeDetails;



@Entity
@Table(name="MasterAccount")
public class MasterAccount {
	@OneToOne(cascade=CacheType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="userid")
	private Set<register> register;
	
	@Column(name="User_Id")
	private int userid;
	
	@Id
	@Column(name="AccountNo")
	private long accountno;
	
	@Column(name="balance")
	private long balance;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public MasterAccount(int userid, long accountno, long balance) {
		super();
		this.userid = userid;
		this.accountno = accountno;
		this.balance = balance;
	}

	public MasterAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
