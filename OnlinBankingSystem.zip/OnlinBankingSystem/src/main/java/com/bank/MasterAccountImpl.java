package com.bank;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


@Repository
public class MasterAccountImpl  implements MasteraccountRepository{
	@PersistenceContext
	EntityManager entityManager;

	@Transactional
	public  List<MasterAccount> getAlluserid() {
		String s = "From MasterAccount";
		Query query = entityManager.createQuery(s);
		List<MasterAccount> MasterAccount = query.getResultList();
		return MasterAccount ;
		
		@Transactional
		public void addAccountNo( ref userid) {
			System.out.println(entityManager);
			entityManager.persist(ref);
			
		}

	

}
