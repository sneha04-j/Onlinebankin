package com.entity.layer6.Status;

public class ForgetPasswordStatus extends Status1 {
	private String password;

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
