package com.entity.layer4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.layer1.Pojo.Admininput;
import com.entity.layer1.Pojo.Payeedetail;
import com.entity.layer2.Repository.PayeedetailRepository;
import com.entity.layer2.Repository.UserdetailRepository;
import com.entity.layer3.DTO.PayeedetailDTO;
import com.entity.layer3.DTO.viewPayeedetail;


@Service
public class PayeedetailServiceImpl implements PayeedetailService {
	
	@Autowired
	PayeedetailRepository repo;
	@Autowired
	UserdetailRepository userRepo;
	

	public List<viewPayeedetail> getPayeeNameAndAccNo(String fromAcc) {
		 return  repo.getPayeedetail(fromAcc);
	}


	@Override
	public void addPayeedetail(PayeedetailDTO payee) throws Exception {
		int uid = 555;
	
		//System.out.println(payee);
 
		//System.out.println(payee.getPayeeAcNumber());
		//System.out.println(payee.getUserAcNumber());
		System.out.println(userRepo.isAccountActive(payee.getPaccno()));
		try {
			if(!userRepo.isAccountActive(payee.getPaccno()))
			{
				throw new Exception("Payee account does not exist");
			}
			else {
				//if(Repo.isAccountPresent(payee.getUserAcNumber(), payee.getPayeeAcNumber()))
					if(repo.isAccountPresent(payee.getUaccno(), payee.getPaccno()))
				{throw new Exception("Payee account already exist");
				} else {
					if(payee.getPaccno().equals(payee.getUaccno())) 
					{
						throw new Exception("Payee account yourself exist");
					} else {
						
						uid++;
					
						Payeedetail payeedetails = new Payeedetail();
						
						payeedetails.setPayeeid(Integer.toString(uid));
						payeedetails.setPayeeaccountnumber(payee.getPaccno());
						payeedetails.setPayeename(payee.getPname());
						payeedetails.setUseraccountnumber(payee.getUaccno());
						System.out.println("hello4");
					//	System.out.println(payeedetails);
						repo.save(payeedetails);
					}
				}
			}
		}catch (Exception e) 
		{
			System.out.println(e.getMessage());
		}
	}	
	
	}
	
