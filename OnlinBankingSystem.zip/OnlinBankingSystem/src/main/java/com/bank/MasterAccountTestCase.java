package com.bank;

import org.junit.jupiter.api.Test;

public class MasterAccountTestCase {
	@Test
	public void addAccountno() {
		MasterAccount Ma = new MasterAccount();
		Ma.setAccountno(10036287);
		
		new MasterAccountImpl().persist(Ma);
	}

}
