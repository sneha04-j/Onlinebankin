package com.entity.layer2;

import java.util.List;


import com.entity.layer1.Logindetail;
import com.entity.layer1.Payeedetail;
import com.entity.layer1.Userdetail;

public interface LoginRepository {
	//void save(Logindetail login);
	

	 List<Logindetail> getUserId();
	//OpenAccount findbyId(String id);
	
	
	//User findUserById(String userId);
	
	//int getNoOfInvalidAttempts(String userId);
	///void setNoOfInvalidAttempts(String userId, int attempts);
	void resetPassword(String userId,String updatedPassword);
	
	//void savelastLogin(String userId,String date);
	//void resetTransactionPassword(String userId,String updatedPassword);
	//String getUserByAccNumber(String accNumber);
	//String getTransactionPassword(String fromAccNumber);
	//List<Logindetail> getUserByAccNumber(String accno);
	//public Logindetail getUserByAccNumber(String accountno);
   // public Logindetail get(String accountno);
	//void resetPassword(String updatedPassword,String accountno);
	//public Logindetail getUserByAccNumber(Userdetail a);
	//public List<Logindetail> getAll();
}
