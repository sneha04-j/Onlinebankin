package com.bank;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface MasteraccountRepository {
	public List<MasterAccount> getAlluserid();
	public void addAccountNo(MasterAccount ref);

}

