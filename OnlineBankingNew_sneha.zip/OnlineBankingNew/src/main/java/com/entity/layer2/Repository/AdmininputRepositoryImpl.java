package com.entity.layer2.Repository;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.entity.layer1.Pojo.Admininput;



@Repository
public class AdmininputRepositoryImpl implements AdmininputRepository{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Transactional
	public void save(Admininput admininputs) {
		
		entityManager.persist(admininputs);
	}
	
	@Transactional
	public Admininput getAdminById(String adminuserid) {
		
	//	Query query= entityManager.createNativeQuery("select * from admininputs a where a.adminuserid="+adminuserid,
		//	Admininput.class);
		//Admininput items = (Admininput) query.getResultList();
					//List<fundTransfer> f=query.getResultList();
		                          //  select * from fundtransfer t where t.FROM_ACCNO=111 OR t.TO_ACCNO=111;
		return entityManager.find(Admininput.class, adminuserid);
		//("getMiniStatement").setParameter("accNumber",accNumber)
	//	return items;
	}
	@Transactional
	
	public String getAdminByIdAndPassword(String adminuserid, String adminpassword) {
	Query query= entityManager.createQuery("select adminuserid from Admininput  where adminuserid='"+adminuserid+"' and adminpassword='"+adminpassword+"'");
				
			
		//Query query= entityManager.createNativeQuery("select * from Admininputs t where t.adminuserid="+adminuserid+" or adminpassword="+adminpassword,Admininput.class);
		String items =(String) query.getSingleResult();
				return items;
				//return entityManager.find(Admininput.class, adminuserid);
	}
}

