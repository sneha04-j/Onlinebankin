package com.entity.layer6.Status;



public class Status1 {
	private StatusType Status;
	private String Message;

	
	public StatusType getStatus() {
		return Status;
	}

	public void setStatus(StatusType status) {
		Status = status;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public static enum StatusType {
		SUCCESS, FAILURE;

		void setMessage(String string) {
			// TODO Auto-generated method stub
			
		}
	}
}


