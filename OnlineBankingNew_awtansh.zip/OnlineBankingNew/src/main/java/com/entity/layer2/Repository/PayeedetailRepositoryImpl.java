package com.entity.layer2.Repository;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.entity.layer1.Pojo.Payeedetail;
import com.entity.layer3.DTO.viewPayeedetail;



@Repository
public class PayeedetailRepositoryImpl implements PayeedetailRepository{

	



	@PersistenceContext
	EntityManager entityManager;
	
	
	
/*	@Transactional
	public List<Payeedetail> getAllRecords() {
		
	/*	Query query= em.createNativeQuery("select * from fundtransfer t where t.FROM_ACCNO="+accNumber+" or t.TO_ACCNO="+accNumber,
			Fundtransfer.class);
		List<Payeedetail> f=query.getResultList();
        //  select * from fundtransfer t where t.FROM_ACCNO=111 OR t.TO_ACCNO=111;
		return em.createNamedQuery("getMiniStatement").setParameter("accNumber",accNumber).getResultList();

		List<viewBeneficiary> beneficiaryList = entityManager.createNamedQuery("getNameAndAccountNumber")
				.setParameter("acno", accNo).getResultList();
		return beneficiaryList;*/
		/*

				Query q = entityManager.createNativeQuery("select * from Payeedetails ", Payeedetail.class);
				List<Payeedetail> f = q.getResultList();
				return f;
	}
				*/

	
	/*@Transactional
	public List<Payeedetail> getAll() {
		
		String s="from Payeedetail";
		Query query = entityManager.createQuery(s);
		List<Payeedetail> payeedetail =query.getResultList();
		return payeedetail;
	}*/
	@Transactional
	public void save(Payeedetail payeedetail) {
		entityManager.persist(payeedetail);
	}

	
			
		
		
	public List<viewPayeedetail> getPayeedetail(String accNo){
		
		//List<viewPayeedetail> PayeeList = entityManager.createNamedQuery("getNameAndAccountNumber")
			//	.setParameter("acno", accNo).getResultList();
		//return PayeeList;
		Query q = entityManager.createNativeQuery("select * from Payeedetails where useraccountnumber="+accNo, Payeedetail.class );
		List<viewPayeedetail> f =q.getResultList();
		return f;
	}
	public boolean isAccountPresent(String fromAcc, String toAcc) {
		Query q = entityManager.createNativeQuery("select count(*) from Payeedetails where useraccountnumber='"+fromAcc+"'and payeeaccountnumber='"+toAcc+"'");
		BigDecimal a = (BigDecimal)q.getSingleResult();
		if(a==(BigDecimal.ZERO))
			return false;
		else 
			return true;	
		}	


	
@Transactional
public String Getmaxpayeeid() {
	       
    //    System.out.println("hello1");
//        Query query = em.createNativeQuery("select max(TRANSAC_ID) from fundtransfer",Fundtransfer.class);
                                           //  "select max(u.TRANSAC_ID) from fundtransfer u"
        //System.out.println("hello2");
          Query query = entityManager.createQuery("select max(payeeid) from payeedetail");
              String c = (String)query.getSingleResult();
       
            //  System.out.println("hello3");
    //    long sdf=query;       
    //    System.out.println("hello4");
    //    return sdf;
       
        return c;
        //return 0;
	}
}




