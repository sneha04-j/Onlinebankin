package com.entity.layer6.Status;



public class UserRegisterStatus extends Status1 {
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}



