package com.entity.layer2.Repository;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer1.Pojo.Logindetail;
import com.entity.layer1.Pojo.Userdetail;





@Repository
public class LoginDetailRepositoryImpl implements LoginDetailRepository {

	@PersistenceContext
	private EntityManager em;
	
	/*@Override
	@Transactional
public void save(Logindetail user) {
		 //TODO Auto-generated method stub
		em.persist(user);
	}*/
	
	//@Override
		@Transactional
		public List<Logindetail> getAl1l() {
			Query query= em.createNativeQuery("select * from  LoginDetails", Logindetail.class);
			
			 List<Logindetail> user= query.getResultList();
			return user;
			
		}

	

	
//	@Transactional
//	public List<Logindetail>getUserId() {
//		// TODO Auto-generated method stub
//		Query q=em.createNativeQuery("select max(u.Userid) from Logindetails u", Logindetail.class);
				
//		return(String) q.getSingleResult();
				
//	}

//	@Override
//	public void save(Logindetail login) {
//		// TODO Auto-generated method stub
		
//	}
	@Transactional
	public List<Logindetail> getUserByAccNumber(String accNumber)
	 {
		
		Query query= em.createNativeQuery("select * from Logindetails u where u.ACCOUNTNUMBER.accountno="+accNumber,Logindetail.class);
				
		
				
					List<Logindetail> items = query.getResultList(); 

					
					return items;
		}

	
	//@Transactional
	//public void resetPassword(String updatedPassword,String accountno) {
	
		
		
		
	//	Query query = em.createNativeQuery("update Logindetails set Login_Password ='"+updatedPassword+"' where ACCOUNTNUMBER ="+accountno,Logindetail.class);
	//	query.executeUpdate();
		
	//}
	


@Transactional
public void resetTransactionPassword(String userId,String updatedPassword) {

	
	
	
	Query query = em.createNativeQuery("update Logindetails set Transaction_Password ='"+updatedPassword+"' where USERID ="+userId,Logindetail.class);
	query.executeUpdate();
	
}
	@Transactional
	public void save(Logindetail user) {
		
		em.persist(user);
		
	}

	public boolean isUserPresent(String userid) {
		 
	Query q = em.createNativeQuery("select count(*) from Logindetails where userid ='"+userid+"'");
	BigDecimal a = (BigDecimal)q.getSingleResult();
	if(a==(BigDecimal.ZERO))
		return false;
	else 
		return true;	
	}	
		
	



	@Override
	public Userdetail findbyId(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAccountRegistered(String accNumber) {
		
		Query q = em.createNativeQuery("select count(*) from Logindetails where accountnumber='"+accNumber+"'");
		//Query q = em.createNativeQuery("Select count(*) from userdetails where accountno='"+acNo+"'");
		BigDecimal a = (BigDecimal)q.getSingleResult();
		if(a==(BigDecimal.ZERO))
			return false;
		else 
			return true;
		
	}

	@Override
	public boolean validUserIdPassword(String userId, String password) {
	Query q = em.createNativeQuery("Select count(*) from logindetails where userid='"+userId+"'and login_password='"+password+"'");
	BigDecimal a = (BigDecimal)q.getSingleResult();
	if(a==(BigDecimal.ZERO))
		return false;
	else 
		return true;
	}

	@Override
	public Logindetail findUserById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isUserValid(String userId) {
		Query q = em.createNativeQuery("select count(*) from logindetails where userid='"+userId+"'");
		BigDecimal a = (BigDecimal)q.getSingleResult();
		if(a==(BigDecimal.ZERO))
			return false;
		else 
			return true;
	}

	@Override
	public int getNoOfInvalidAttempts(String userId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setNoOfInvalidAttempts(String userId, int attempts) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getTransactionPassword(String fromAccNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void savelastLogin(String userId, String date) {
		// TODO Auto-generated method stub
		
	}
	@Transactional
	public void resetPassword(String updatedPassword,String accountno) {

	Query query = em.createNativeQuery("update Logindetails set Login_Password ='"+updatedPassword+"' where accountnumber ="+accountno,Logindetail.class);
	query.executeUpdate();

	}

	@Override
	public List<Logindetail> getAll() {
		// TODO Auto-generated method stub
		return null;
	}


@Override
public List<Logindetail> getUserId() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Logindetail> getAll1() {
	// TODO Auto-generated method stub
	return null;
}

}

