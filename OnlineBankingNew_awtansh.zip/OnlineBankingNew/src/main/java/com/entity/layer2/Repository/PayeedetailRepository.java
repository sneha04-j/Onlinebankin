package com.entity.layer2.Repository;

import java.util.List;

import com.entity.layer1.Pojo.Payeedetail;
import com.entity.layer3.DTO.viewPayeedetail;


public interface PayeedetailRepository {
	

	//public List<Payeedetail> getAll();
		//List<Payeedetail> getAllRecords();

		void save(Payeedetail payeedetails);

		List<viewPayeedetail> getPayeedetail(String fromAcc);

		boolean isAccountPresent(String userAcNumber, String userAcNumber2);
		public String Getmaxpayeeid();
		
		
		
		
		
		


}
