package com.entity.layer4.service;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.entity.layer1.Pojo.Admininput;
import com.entity.layer2.Repository.AdmininputRepository;
import com.entity.layer3.DTO.AdmininputDTO;


@Service
public class AdmininputServiceImpl implements AdmininputService{
	
	@Autowired
	private AdmininputRepository repo;
	@Override
	public void registerAdmin(Admininput admin) {
		// TODO Auto-generated method stub
		Admininput obj = repo.getAdminById(admin.getAdminuserid());
	
		if(obj==null) {
			repo.save(admin);
		}else {
			System.out.println("User Already Exists");
		}
		
	}
		
		@Override
		public Admininput adminLogin(AdmininputDTO admininputDTO)
		{
			
			try {
//				System.out.println("user "+adminCredentials.getUserId());
//				System.out.println("value is "+repo.findAdminById(adminCredentials.getUserId()));
			//	if(!repo.isAdminAvailable(admininputDTO.getUserId())) {
//					System.out.println("printing this");
				//	System.out.println("User Not Exist");
				//}
				String userId = repo.getAdminByIdAndPassword(admininputDTO.getUserId(), admininputDTO.getPassword());
				Admininput admin = repo.getAdminById(userId);
				//List<Admininput> admin = repo.getAdminById(userId.);
//				System.out.println("Admin is service is " +admin);
				return admin;
			}
			catch(EmptyResultDataAccessException e){
				System.out.println("Incorrect UserId/Password");
			}
			return null;
		}
		/*	@Override
	public Admininput adminLogin(AdmininputDTO adminCredentials)
	{
		// TODO Auto-generated method stub
		try {
//			System.out.println("user "+adminCredentials.getUserId());
//			System.out.println("value is "+repo.findAdminById(adminCredentials.getUserId()));
			if(!repo.isAdminAvailable(adminCredentials.getUserId())) {
//				System.out.println("printing this");
				throw new ServiceException("User Not Exist");
			}
			String userId = repo.getAdminByIdAndPassword(adminCredentials.getUserId(), adminCredentials.getPassword());
			System.out.println(userId);
			Admininput admin = repo.getAdminById(userId);
//			System.out.println("Admin is service is " +admin);
			return admin;
		}
		catch(EmptyResultDataAccessException e){
			throw new ServiceException("Incorrect UserId/Password");
		}
	}*/

}
