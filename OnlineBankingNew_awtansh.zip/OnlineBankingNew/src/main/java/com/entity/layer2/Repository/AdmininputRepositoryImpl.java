package com.entity.layer2.Repository;



import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.entity.layer1.Pojo.Admininput;



@Repository
public class AdmininputRepositoryImpl implements AdmininputRepository{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Transactional
	public void save(Admininput admininputs) {
		
		entityManager.persist(admininputs);
	}
	
	@Transactional
	public Admininput getAdminById(String adminuserid) {
		
	//	Query query= entityManager.createNativeQuery("select * from admininputs a where a.adminuserid="+adminuserid,
		//	Admininput.class);
		//Admininput items = (Admininput) query.getResultList();
					//List<fundTransfer> f=query.getResultList();
		                          //  select * from fundtransfer t where t.FROM_ACCNO=111 OR t.TO_ACCNO=111;
		return entityManager.find(Admininput.class, adminuserid);
		//("getMiniStatement").setParameter("accNumber",accNumber)
	//	return items;
	}
	@Transactional
	
	public String getAdminByIdAndPassword(String adminuserid, String adminpassword) {
	Query query= entityManager.createQuery("select adminuserid from Admininput  where adminuserid='"+adminuserid+"' and adminpassword='"+adminpassword+"'");
				
			
		//Query query= entityManager.createNativeQuery("select * from Admininputs t where t.adminuserid="+adminuserid+" or adminpassword="+adminpassword,Admininput.class);
		String items =(String) query.getSingleResult();
				return items;
				//return entityManager.find(Admininput.class, adminuserid);
	}
}
/*	@Transactional
	public String getAdminByIdAndPassword(String adminuserid, String adminpassword) {
	Query query= entityManager.createQuery("select a.adminuserid from Admininput a where a.adminuserid=:x and a.adminpassword=:y");
	query.setParameter("x",adminuserid);
	query.setParameter("y",adminpassword);
//	System.out.println("hello1");
		//Query query= entityManager.createNativeQuery("select * from Admininputs t where t.adminuserid="+adminuserid+" or adminpassword="+adminpassword,Admininput.class);
			
	
	String items = (String)query.getSingleResult();
			//	System.out.println("hello");
				return items;
	}

	public boolean isAdminAvailable(String adminuserid) {
		System.out.println("userId is "+adminuserid);
		BigDecimal res  = (BigDecimal) entityManager.createNativeQuery("select count(a.adminUserID) from Admininputs a where a.adminUserID ="+adminuserid)
				/.setParameter("id", adminuserid)/.getSingleResult();
		System.out.println("count is "+res);
		int intNumber = res.intValue();
//		return (Long) entityManager.createNativeQuery("select count(a.adminUserID) from Admininputs a where a.adminUserID ="+adminuserid)
		//		/.setParameter("user", adminuserid)/.getSingleResult() == 1 ? true : false;
		System.out.println("count is "+intNumber);
		System.out.println("admin exist.....");
	return intNumber ==  1 ? true : false;
	
	}*/


