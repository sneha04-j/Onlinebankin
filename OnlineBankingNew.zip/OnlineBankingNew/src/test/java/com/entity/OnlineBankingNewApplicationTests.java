package com.entity;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.layer1.Admininput;
import com.entity.layer1.Fundtransfer;
import com.entity.layer1.Logindetail;
import com.entity.layer1.Payeedetail;
import com.entity.layer1.Userdetail;
import com.entity.layer2.AdmininputRepository;
import com.entity.layer2.FundTransferRepository;
import com.entity.layer2.LoginRepository;
import com.entity.layer2.PayeedetailRepository;

@SpringBootTest
class OnlineBankingNewApplicationTests {
	
	@Autowired
	FundTransferRepository a;
	@Autowired
	PayeedetailRepository   b;
	@Autowired
	AdmininputRepository    c;
	@Autowired
	LoginRepository   d;

	@Test
	void contextLoads() {
		
		List<Fundtransfer> f=a.getAllRecords("111");
		
		for(Fundtransfer ab:f)
		{
			System.out.println(ab.getAmount());
		}
		
	}

	@Test
	void contextLoads1() {
		List<Payeedetail> get=b.getAllRecords();
		for(Payeedetail pd:get)
		{ 
			System.out.println(pd.getPayeeid());
			System.out.println(pd.getPayeename());
			System.out.println(pd.getUseraccountnumber());
			System.out.println(pd.getPayeeaccountnumber());
					
		}
	}
	
	@Test
	void contextLoads2() {
	Payeedetail pd = new Payeedetail();
		
		pd.setPayeeaccountnumber("444");
		pd.setPayeeid("104");
		pd.setPayeename("sneha");
		pd.setUseraccountnumber("555");
		
		
		b.save(pd);
		
	}
	@Test
	void contextLoads3() {
	Admininput ai = new Admininput();
		
		ai.setAdminname("awtansh");
		ai.setAdminpassword("Awtansh@2");
		ai.setAdminuserid("2");
		
		c.save(ai);
}
	@Test
	void contextLoads4() {
		
		List<Admininput> f =c.getAdminById("2");
		
		for(Admininput ad:f)
		{
			System.out.println(ad.getAdminname());
			System.out.println(ad.getAdminpassword());
			
		}
		
	}
	@Test
	void contextLoads5() {
		
		List<Admininput> f =c.getAdminByIdAndPassword("2", "Awtansh@2");
		
		for(Admininput ad:f)
		{
			System.out.println(ad.getAdminname());
			
		}
	}

	@Test
	void contextLoads6() {

		d.resetPassword("bbb", "'111'");

	
}
	@Test
	void contextLoads7() {
		List<Logindetail> get=d.getUserId();
		for(Logindetail ld:get)
		{ 
			System.out.println(ld.getUserid());
		}
	}
			
					
		}
	/*	@Test
	void contextLoads7() {
	//Userdetail u = new Userdetail();
	//String a ="222";
	
	//List<Logindetail> f =d.getUserByAccNumber(a);
	List<Logindetail> f =d.getAll();
	for(Logindetail ld:f)
	{
		//System.out.println(f.getLastlogin());
		System.out.println(ld.getAccountno().getFirstname());
	}
	}
	
	
	/*	System.out.println(ld.getLoginPassword());
		System.out.println(ld.getTransactionPassword());
		System.out.println(ld.getUserid());
		System.out.println(ld.getNumberofinvalidattempts());
		//System.out.print(ld.get);
		
	

	/*@Test
void userbyAccountnoTest() {
//	Userdetail u = 10001;
	Logindetail l =d.getUserByAccNumber("111");
	
	
	//{
//		System.out.println(l.getLastlogin());
//		System.out.println(l.getLoginPassword());
//		System.out.println(l.getTransactionPassword());
//		System.out.println(l.getUserid());
//		System.out.println(l.getNumberofinvalidattempts());
		
	//}
	
}*/
