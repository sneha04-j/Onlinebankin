package com.entity.layer4.service;



import com.entity.layer1.Pojo.Admininput;
import com.entity.layer3.DTO.AdmininputDTO;


public interface AdmininputService {
	
	
	void registerAdmin(Admininput admin);
	
	
	
	Admininput adminLogin(AdmininputDTO admininputDTO);
	
	
	
//	void registerAdmin(Admin admin);
//	Admin adminLogin(AdminCredentials adminCredentials);
//}
}

