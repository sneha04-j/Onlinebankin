package com.entity.layer2;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.entity.layer1.Logindetail;
import com.entity.layer1.Payeedetail;
import com.entity.layer1.Userdetail;

@Repository
public class LoginImpl implements LoginRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void resetPassword(String updatedPassword,String accountno) {

	Query query = entityManager.createNativeQuery("update Logindetails set Login_Password ='"+updatedPassword+"' where accountnumber ="+accountno,Logindetail.class);
	query.executeUpdate();

	}
	public List<Logindetail> getUserId(){
		Query q = entityManager.createNativeQuery("select userid from logindetails ", Logindetail.class);
		List<Logindetail> f = q.getResultList();
		return f;
	}
	
}
	
	
	/*@Transactional
	public List<Logindetail> getUserByAccNumber(String accno ) {
		
		Query query= entityManager.createNativeQuery("select * from logindetails, userdetails where logindetails.accountnumber="+accno,
		
				Logindetail.class);
	//	select u.userId from User u where u.accountNumber.accountNumber =:accNumber

				 List<Logindetail> items = query.getResultList(); 
				return items;

}
		@Transactional
	public Logindetail getUserByAccNumber(Userdetail a) {
			//Query q = null;
			String query = "from Logindetail where userdetail2 =:x";
	   Query     q = (Query) this.entityManager.createQuery(query);
	        q.setParameter("x", a);
	        Logindetail cs = (Logindetail)q.getSingleResult();
	       // System.out.println(cs.getLastlogin());
	          
		return cs;
	
	}
		@Transactional
	    public List<Logindetail> getAll() {
	        String s="from Logindetail";
	        Query query = entityManager.createQuery(s);
	        List<Logindetail> logindetail=query.getResultList();
	        return logindetail;
		}
	/*public Logindetail get(String accountno)
	{
		 
			   
		       
		        Logindetail re = entityManager.find(Logindetail.class, accountno);
				return re;
	}
	
		@Override
		public Logindetail get(String accountno) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public Logindetail getUserByAccNumber(String accountno) {
			// TODO Auto-generated method stub
			return null;
		}
}*/
