package com.entity.layer2.Repository;



import com.entity.layer1.Pojo.Admininput;

public interface AdmininputRepository {
	void save(Admininput admininputs);
	Admininput getAdminById(String userId);
	
	String getAdminByIdAndPassword(String adminuserid, String adminpassword);
	
}

