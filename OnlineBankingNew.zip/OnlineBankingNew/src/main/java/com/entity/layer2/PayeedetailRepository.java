package com.entity.layer2;

import java.util.List;

import com.entity.layer1.Payeedetail;

public interface PayeedetailRepository {

	//public List<Payeedetail> getAll();
		List<Payeedetail> getAllRecords();

		void save(Payeedetail payeedetails);

	}
