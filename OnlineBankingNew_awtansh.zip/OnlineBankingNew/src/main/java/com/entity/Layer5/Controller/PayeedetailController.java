package com.entity.Layer5.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.layer3.DTO.PayeedetailDTO;
import com.entity.layer3.DTO.viewPayeedetail;
import com.entity.layer4.service.PayeedetailServiceImpl;
import com.entity.layer6.Status.Status1;
import com.entity.layer6.Status.Status1.StatusType;




//@CrossOrigin(origins =  "http://localhost:4200")
@RestController
public class PayeedetailController {
	
	@Autowired
	PayeedetailServiceImpl service;
	
	@GetMapping("/getPayeeNameAndAccountNo/{fromAcc}")
	public List<viewPayeedetail> getName(@PathVariable("fromAcc") String fromAcc) {
		return service.getPayeeNameAndAccNo(fromAcc);
	}
	
	@PostMapping(path = "/addPayee")
	public Status1 addNewPayee(@RequestBody PayeedetailDTO payee) {
		//System.out.println(payee);
		try {
			service.addPayeedetail(payee);
		
			Status1 status = new Status1();
			status.setMessage("Payee Added");
			status.setStatus(StatusType.SUCCESS);
			return status;
		}
		catch(Exception e) 
		{
			Status1 status = new Status1();
			status.setMessage(e.getMessage());
			status.setStatus(StatusType.FAILURE);
			return status;
		}
}
}