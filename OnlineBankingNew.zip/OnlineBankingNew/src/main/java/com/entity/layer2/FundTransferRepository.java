package com.entity.layer2;

import java.util.List;

import com.entity.layer1.Fundtransfer;


public interface FundTransferRepository {

	
	
	
	void save(Fundtransfer fundtransfe);
	
	
	int getTransactionId();

	
	List<Fundtransfer> getAllRecords(String accNumber);
	
	
	List<Fundtransfer> getTransactionBetweenDates(String fromDate,String toDate,String accountnumber);
	
}
