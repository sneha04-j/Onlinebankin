package com.entity.Layer5.Controller;



import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.layer1.Pojo.Admininput;
import com.entity.layer3.DTO.AdmininputDTO;
import com.entity.layer4.service.AdmininputService;
import com.entity.layer6.Status.LoginStatus;
import com.entity.layer6.Status.Status1;
import com.entity.layer6.Status.Status1.StatusType;




//@CrossOrigin(origins = "http://localhost:4200")


@RestController
public class AdmininputController {
	@Autowired
	private AdmininputService service;
	
	@PostMapping(path="/registerAdmin")
	public Status1 registerAdmin(@RequestBody Admininput admin) {
		try {
			service.registerAdmin(admin);
			Status1 registerStatus = new Status1();
			registerStatus.setStatus(StatusType.SUCCESS);
			registerStatus.setMessage("User Registered");
			return registerStatus;
		}
	catch(ServiceException e) {
			Status1 registerStatus = new Status1();
			registerStatus.setStatus(StatusType.FAILURE);
			registerStatus.setMessage("not registered");
			return registerStatus;
	}
		}
	@PostMapping(path="/Loginadmin")
	public LoginStatus adminLogin(@RequestBody AdmininputDTO admininputDTO) {
		try {
			Admininput admin = service.adminLogin(admininputDTO);
			LoginStatus s= new LoginStatus();
			//service.adminLogin(admininputDTO)
		//	List<Admininput> admin = service.adminLogin(admininputDTO);
			//LoginStatus loginStatus = new LoginStatus();
			s.setName(admin.getAdminname());
			s.setUserId(admin.getAdminuserid());
			s.setMessage("Login Successful");
			s.setStatus(StatusType.SUCCESS);
			return s;
		}
		catch(ServiceException e) {
			LoginStatus loginStatus = new LoginStatus();
			loginStatus.setMessage(e.getMessage());
			loginStatus.setStatus(StatusType.FAILURE);
			return loginStatus;
		}
	}
}
